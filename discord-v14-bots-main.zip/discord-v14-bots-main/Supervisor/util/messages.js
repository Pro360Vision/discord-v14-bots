module.exports = {
    giveaway: `> **🎉 Çekiliş Başladı!**`,
    giveawayEnded:`> **🎉 Çekiliş Sona Erdi!**`,
    noWinner: `Kazanan Bulunmamakta!`,
    winMessage:`> 🎉 **{this.prize} Ödülünü {winners} Kazandı!**\n{this.messageURL}`,
    title: '{this.prize}',
    inviteToParticipate: 'Katılmak İçin 🎉 Tepkisine Basın',
    drawing: 'Kalan Süre: {timestamp}',
    dropMessage: 'İlk Tepkiye Basan Sen Ol 🎉!',
    embedFooter: '{this.winnerCount} Kazanan',
    winners: 'Kazanan:',
    endedAt: 'Sona Erme',
    hostedBy: 'Hosted: {this.hostedBy}',
    }