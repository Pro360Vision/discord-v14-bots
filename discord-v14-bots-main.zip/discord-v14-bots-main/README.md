[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Delicious+Handrawn&size=60&pause=1000&color=00F743&repeat=false&width=800&height=100&lines=Discord+V14+PM2+Bots+%23By+Be%C5%9F)](#)
<br> </br>
<h2>🟢 20.06.23 - Discord'daki Yeni Tag Sistemine Göre Düzenlenmiştir.</h2>
<br> </br>
<br> </br>
<a href="https://discord.gg/zSPzyGhtyP">[ ❓ ] Altyapıyı Kurdun Ve Hata Alıyorsan Buraya Tıkla!</a>
<br> </br>
<a href="#napirs">[ ⚠️ ] @napi-rs/canvas Hatası Alıyorsan Buraya Tıkla!</a>
<br> </br>
<strong>Discord sunucularınızda kullanabileceğiniz setuplı son model v14 pm2 botları.</strong>
<br> </br>

[![Discord Banner](https://api.weblutions.com/discord/invite/luppux/)](https://discord.gg/luppux)
<br> </br>
<br> </br>
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Delicious+Handrawn&size=30&pause=1000&color=F70909&repeat=false&width=435&lines=%E2%9D%93+Kurulum+)](https://git.io/typing-svg)

- İlk olarak bilgisayarına [Node JS](https://nodejs.org/en/) `(en düşük v16)` indir.

- ⚠️ Altyapı Lisanslı, Paylaşım vb. Olursa Donunuza Kadar Alırım.
- Daha sonra altyapıyı indirip `./beş_config.js` dosyalarını doldurun.
- sonrasında modülleri kurmak için terminale aşşağıdaki kodu yaz.

```diff
npm install
```
- `.setup` komudu ile kurulumu yapmaya başla!
- Bu kadar bot hazır.
- `.yardım:` komuduyla tüm komutlara ulaşabilirsin.
- örnek kurulum `.setup 1 @register staff` komuduyla kurulum yapabilirsiniz.
- tüm ID'leri görmek için `.setup` yazabilirsiniz.
- `.setup 1 sıfırla ` yaparsanız 1.ID'deki veriyi temizler.
<br> </br>
<br> </br>
- Welcome Botlar [acarfx](https://github.com/acarfx)'e Ait.
- Yetki Yükseltimide Githubdan Bi Repodan Kopyaladım Unuttum Adını,Herkeste Olan Şey İşte.
<br> </br>
<br> </br>
<h1>⚠️ @napi-rs/canvas Hatası</h1>
<h2 id="napirs">Hatanın msvc'den Kaynaklı Alttaki Linkten Gerekli Driver'ları Kurabilirsiniz.</h2>
Driver'ı Yüklemek İçin; https://fivesobes.gitbook.io/canvafy/welcome/resolve-errors
Driver Yüklendikten Sonra Makinenizi/Bilgisayarınızı Yeniden Başlatınız.
Hata Düzelicektir.
<br> </br>
<br> </br>

- [Discord Profilim](https://discord.com/users/928259219038302258)

- Herhangi bir hata bulmanız durumunda luppux'a ulaşabilirsiniz ^^
<br> </br>
[![Discord Banner](https://api.weblutions.com/discord/invite/luppux/)](https://discord.gg/luppux)
